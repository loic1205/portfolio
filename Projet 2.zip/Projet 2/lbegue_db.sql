-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 07 juin 2024 à 20:04
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `lbegue_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `character_sheet`
--

DROP TABLE IF EXISTS `character_sheet`;
CREATE TABLE IF NOT EXISTS `character_sheet` (
  `cs_id` int NOT NULL AUTO_INCREMENT,
  `cs_name` varchar(255) DEFAULT NULL,
  `cs_classe` int DEFAULT NULL,
  `cs_race` int DEFAULT NULL,
  `cs_arme` int DEFAULT NULL,
  `usr_id` int NOT NULL,
  PRIMARY KEY (`cs_id`),
  UNIQUE KEY `id_usr` (`usr_id`),
  UNIQUE KEY `cs_srace` (`cs_arme`),
  KEY `cs_classe` (`cs_classe`),
  KEY `cs_race` (`cs_race`),
  KEY `cs_name` (`cs_name`),
  KEY `cs_arme` (`cs_arme`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `character_sheet`
--

INSERT INTO `character_sheet` (`cs_id`, `cs_name`, `cs_classe`, `cs_race`, `cs_arme`, `usr_id`) VALUES
(1, 'Uk', 1, 1, 10, 2);

-- --------------------------------------------------------

--
-- Structure de la table `dnd_arme`
--

DROP TABLE IF EXISTS `dnd_arme`;
CREATE TABLE IF NOT EXISTS `dnd_arme` (
  `arme_id` int NOT NULL AUTO_INCREMENT,
  `arme_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`arme_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `dnd_arme`
--

INSERT INTO `dnd_arme` (`arme_id`, `arme_name`) VALUES
(1, 'épée courte'),
(2, 'épée polyvalente'),
(3, 'épée à deux mains'),
(4, 'lance'),
(5, 'pique'),
(6, 'faux'),
(7, 'marteau de guerre'),
(8, 'marteau léger'),
(9, 'hache à deux mains'),
(10, 'hache légère');

-- --------------------------------------------------------

--
-- Structure de la table `dnd_class`
--

DROP TABLE IF EXISTS `dnd_class`;
CREATE TABLE IF NOT EXISTS `dnd_class` (
  `class_id` int NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `dnd_class`
--

INSERT INTO `dnd_class` (`class_id`, `class_name`) VALUES
(1, 'Barbare'),
(3, 'Barde'),
(4, 'Clerc'),
(5, 'Combattant'),
(6, 'Druide'),
(7, 'Ensorceleur'),
(8, 'Magicien'),
(9, 'Moine'),
(10, 'Occultiste'),
(11, 'Paladin'),
(12, 'Rodeur'),
(13, 'Roublard');

-- --------------------------------------------------------

--
-- Structure de la table `dnd_race`
--

DROP TABLE IF EXISTS `dnd_race`;
CREATE TABLE IF NOT EXISTS `dnd_race` (
  `race_id` int NOT NULL AUTO_INCREMENT,
  `race_name` varchar(255) NOT NULL,
  PRIMARY KEY (`race_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `dnd_race`
--

INSERT INTO `dnd_race` (`race_id`, `race_name`) VALUES
(1, 'Demi_elfe'),
(2, 'Elfe'),
(3, 'Drakéide'),
(4, 'Nain'),
(5, 'Humain'),
(6, 'Drow'),
(7, 'Gnome'),
(8, 'Githyankis'),
(9, 'Halfelin'),
(10, 'Tieffelin');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `usr_id` int NOT NULL AUTO_INCREMENT,
  `usr_login` varchar(255) NOT NULL,
  `usr_pwd` varchar(255) NOT NULL,
  `usr_ip_inscription` int NOT NULL,
  `usr_ip_last_connection` varchar(45) DEFAULT NULL,
  `usr_date_last_connection` date NOT NULL,
  PRIMARY KEY (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`usr_id`, `usr_login`, `usr_pwd`, `usr_ip_inscription`, `usr_ip_last_connection`, `usr_date_last_connection`) VALUES
(1, 'loicbegue', '$2y$10$IYa9fBDnHagpkf69fY0zK.dwZSpcYmIx6xukRQhDBuozDHuBGLBsu', 0, NULL, '0000-00-00'),
(2, 'test', '86750a3135d2fb467af43166ee83959a26da5803f9816970674859dad562ad10', 0, '::1', '2024-06-07');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `character_sheet`
--
ALTER TABLE `character_sheet`
  ADD CONSTRAINT `character_sheet_ibfk_1` FOREIGN KEY (`usr_id`) REFERENCES `user` (`usr_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `character_sheet_ibfk_2` FOREIGN KEY (`cs_arme`) REFERENCES `dnd_arme` (`arme_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `character_sheet_ibfk_3` FOREIGN KEY (`cs_race`) REFERENCES `dnd_race` (`race_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `character_sheet_ibfk_4` FOREIGN KEY (`cs_classe`) REFERENCES `dnd_class` (`class_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_arme` FOREIGN KEY (`cs_arme`) REFERENCES `dnd_arme` (`arme_id`),
  ADD CONSTRAINT `fk_classe` FOREIGN KEY (`cs_classe`) REFERENCES `dnd_class` (`class_id`),
  ADD CONSTRAINT `fk_race` FOREIGN KEY (`cs_race`) REFERENCES `dnd_race` (`race_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
