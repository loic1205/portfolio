<?php include "debut_pages.php";

include "debut_pages_affichable.php";
?>

<div id=contenu class=myDiv>
    <p class=center>
        Bienvenue dans l'univers de Donjons et Dragons.
        <br><br>
        Ici, vous pouvez créer le personnage de vos rêve sur l'univers de D&D.
        <br><br>
        Préparer vos fiches de personnages,
        <br><br>
        chauffez vos dés
        <br><br>
        et lancer vous à l'aventure !
    </p>


    <?php include "fin_pages.php"; ?>