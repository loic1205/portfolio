<?php 
setcookie('usr_id',false);
setcookie('usr_id_hash',false);
header('location:index.php');
?>