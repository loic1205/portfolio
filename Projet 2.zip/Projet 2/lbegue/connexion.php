<?php
include "debut_pages_affichable.php";

if (isAuthentified()) header('location:index.php');

// Traitements
$messageError = '';

if (isset($_POST['login'])) {
   $login = $_POST['login'];
   $pwd = hash('sha256', $_POST['pwd1'] . $GdS . 'PWD');
   $auth = $CO->prepare('SELECT usr_id FROM user 
      WHERE (usr_login=:login) 
      AND usr_pwd=:pwd');
   $auth->execute(array(':login' => $login, ':pwd' => $pwd));

   if ($user = $auth->fetch(PDO::FETCH_ASSOC)) {  // bien authentifié 
      $usr_id = $user['usr_id'];
      $usr_id_hash = hash('sha256', $usr_id . $GdS . 'CO');
      $ip = $_SERVER['REMOTE_ADDR'];
      $date = date('Y-m-d');
      $time = isset($_POST['rememberme']) ? time() + 25 * 30 * 24 * 3600 : 0;
      setcookie('usr_id', $usr_id, $time);
      setcookie('usr_id_hash', $usr_id_hash, $time);
      // met à jour la date et l'IP de dernière connexion
      $update = $CO->prepare('UPDATE user 
         SET usr_ip_last_connection =:ip, usr_date_last_connection =:date 
         WHERE usr_id = :usr_id');
      $update->execute(
         array(':ip' => $ip, ':date' => $date, ':usr_id' => $usr_id)
      );
      header('location:index.php');
   } else // erreur de login ou de mot de passe
      $messageError = '<i style=color:red; class="fa-solid fa-circle-exclamation"></i> Erreur d\'authentification';
}

$message = '';
if (isset($_GET['justSubscribe'])) $message = "Vous êtes bien inscrit, merci de vous authentifier";

?>

<div id=contenu class=myDiv>
   <form method=post>
      <h1 class=titre_connexion>Connectez-vous sur notre site</h1>
      <table>
         <tr>
            <td class=msgOK colspan=2><?= $message; ?>
         <tr>
            <td class=error colspan=2><?= $messageError; ?>
         <tr>
            <td>Login *:
            <td><input name=login required value="<?= isset($_POST['login']) ? htmlspecialchars($_POST['login'], ENT_QUOTES) : ""; ?>">
         <tr>
            <td>Mot de passe *:
            <td><input name=pwd1 type=password required><br>
         <tr>
            <td>
            <td><input type=checkbox id=rememberme name=rememberme><label for=rememberme>Se souvenir de moi
         <tr>
            <td>
            <td><input type=submit value=Connexion>
         <tr>
            <td>
            <td colspan=2><small>(* : champs obligatoires)
      </table>
   </form>
   <?php include "fin_pages.php"; ?>