<?php
include "debut_pages.php";
if (!isAuthentified()) header('location:index.php');

$error_mdp = $ok_mdp = '';

// Récupérer les classes, races, et armes depuis la base de données
$classes = [];
$races = [];
$armes = [];

try {
    $classQuery = $CO->query("SELECT class_id, class_name FROM dnd_class");
    $classes = $classQuery->fetchAll(PDO::FETCH_ASSOC);

    $raceQuery = $CO->query("SELECT race_id, race_name FROM dnd_race");
    $races = $raceQuery->fetchAll(PDO::FETCH_ASSOC);

    $armeQuery = $CO->query("SELECT arme_id, arme_name FROM dnd_arme");
    $armes = $armeQuery->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Gestion des erreurs de connexion à la base de données
    echo "Erreur : " . $e->getMessage();
}

// Traitements de l'insertion de données dans la table character_sheet
if (isset($_POST['cs_name'])) {
    $cs_name = $_POST['cs_name'];
    $cs_classe = $_POST['cs_classe'];
    $cs_race = $_POST['cs_race'];
    $cs_arme = $_POST['cs_arme'];
    $usr_id = $_COOKIE['usr_id']; // Get the user ID from the cookie

    $insert = $CO->prepare('INSERT INTO character_sheet (cs_name, cs_classe, cs_race, cs_arme, usr_id) 
                            VALUES (:cs_name, :cs_classe, :cs_race, :cs_arme, :usr_id)');
    $insert->execute(array(':cs_name' => $cs_name, ':cs_classe' => $cs_classe, ':cs_race' => $cs_race, ':cs_arme' => $cs_arme, ':usr_id' => $usr_id));
}

// Traitements pour préparer l'affichage
$rsUser = $CO->prepare('SELECT * FROM user WHERE usr_id = :usr_id');
$rsUser->execute(array(':usr_id' => $_COOKIE['usr_id']));

$character_sheet = $rsUser->fetch(PDO::FETCH_ASSOC);

$cs_name = isset($character_sheet['cs_name']) ? htmlspecialchars($character_sheet['cs_name'], ENT_QUOTES) : '';
$cs_classe = isset($character_sheet['cs_classe']) ? htmlspecialchars($character_sheet['cs_classe'], ENT_QUOTES) : '';
$cs_race = isset($character_sheet['cs_race']) ? htmlspecialchars($character_sheet['cs_race'], ENT_QUOTES) : '';
$cs_arme = isset($character_sheet['cs_arme']) ? htmlspecialchars($character_sheet['cs_arme'], ENT_QUOTES) : '';

// Affichage de la page
include "debut_pages_affichable.php";
?>

<div id="contenu" class="myDiv" style="display:flex; justify-content:space-between">
    <form method="post">
        <h1>Créer une fiche de personnage</h1>
        <table>
            <tr>
                <td>Nom :</td>
                <td><input name="cs_name" placeholder="Nom du personnage" value="<?= $cs_name ?>"></td>
            </tr>
            <tr>
                <td>Classe :</td>
                <td>
                    <select name="cs_classe">
                        <?php foreach ($classes as $classe) : ?>
                            <option value="<?= $classe['class_id'] ?>" <?= $classe['class_id'] == $cs_classe ? 'selected' : '' ?>><?= $classe['class_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Race :</td>
                <td>
                    <select name="cs_race" id="race">
                        <?php foreach ($races as $race) : ?>
                            <option value="<?= $race['race_id'] ?>" <?= $race['race_id'] == $cs_race ? 'selected' : '' ?>><?= $race['race_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Arme :</td>
                <td>
                    <select name="cs_arme" id="arme">
                        <?php foreach ($armes as $arme) : ?>
                            <option value="<?= $arme['arme_id'] ?>" <?= $arme['arme_id'] == $cs_arme ? 'selected' : '' ?>><?= $arme['arme_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Modifier"></td>
            </tr>
        </table>
    </form>
</div>

<?php include "fin_pages.php"; ?>