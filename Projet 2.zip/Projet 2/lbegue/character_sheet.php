<?php
include "debut_pages.php";
include "debut_pages_affichable.php";

try {
    // Requête pour récupérer les enregistrements
    $get = $CO->query('
        SELECT cs.cs_id, cs.cs_name, dc.class_name, dr.race_name, da.arme_name 
        FROM character_sheet cs
        JOIN dnd_arme da ON cs.cs_arme = da.arme_id
        JOIN dnd_class dc ON cs.cs_classe = dc.class_id
        JOIN dnd_race dr ON cs.cs_race = dr.race_id
    ');

    // Affichage des enregistrements
?>
    <div id="contenu" class="myDiv" style="display:flex; justify-content:space-between">
    <?php
    echo "<div class='card'>";
    echo "<table border='1'>";
    echo "<tr><th>Nom</th><th>Classe</th><th>Race</th><th>Arme</th></tr>"; // Remplacez les en-têtes par vos colonnes

    while ($row = $get->fetch(PDO::FETCH_ASSOC)) {
        $cs_id = htmlspecialchars($row['cs_id']); // Récupérer la valeur de cs_id
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['cs_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['class_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['race_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['arme_name']) . "</td>";
        echo "</tr>";
        echo "</tr>";
        echo "<h1>Fiche de personnage n°" . $cs_id . "</h1>"; // Affichage de la valeur de cs_id
    }
    echo "</table>";
    echo "</div>";
} catch (PDOException $e) {
    // Gestion des erreurs de connexion à la base de données
    echo "Erreur : " . $e->getMessage();
}

include "fin_pages.php";
    ?>