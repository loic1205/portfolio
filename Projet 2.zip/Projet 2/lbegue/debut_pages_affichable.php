<?php if (!isset($debut_pages)) include "debut_pages.php"; ?>
<!DOCTYPE html>
<html lang=fr>

<head>
	<title>mon site Web</title>
	<meta charset=utf8>
	<script src="https://kit.fontawesome.com/b8e5a4dc71.js" crossorigin="anonymous"></script>
</head>

<body>
	<div id=banniere>

		<a href=index.php>
			<img id=logo_G width=120 src=https://logos-world.net/wp-content/uploads/2021/12/DnD-Symbol.png></a>

		<div id=banner_title>D&D world</div>

		<a href=<?= isAuthentified() ? 'compte.php' : 'connexion.php'; ?>>
			<img id=logo_D width=90 src=https://i.etsystatic.com/15665076/r/il/5d4259/4474165108/il_570xN.4474165108_gpnq.jpg></a>
	</div>

	<div id=menuH class="center myDiv">

		<a href=index.php><i class="fa-solid fa-house"></i> Accueil</a>

		<?php
		if (!isAuthentified())
			echo '<a href=inscription.php><i class="fa-solid fa-circle-user"></i> Inscription</a>
			    <a href=connexion.php><i class="fa-solid fa-right-to-bracket"></i> Connexion</a>';
		else
			echo '<a href=déconnexion.php><i class="fa-solid fa-power-off"></i> Déconnexion</a>
			<a href=toolbox.php><i class="fa-solid fa-address-card"></i> toolbox</a>';
		?>
		<a href=classe.php><i class="fa-solid fa-dice-six"></i> D&D classes</a>
		<a href=character_sheet.php><i class="fa-sharp fa-solid fa-file-zipper"></i> Fiche de personnage</a>
	</div>
	<div id=principal>