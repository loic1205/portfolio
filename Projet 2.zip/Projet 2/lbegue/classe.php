<?php include "debut_pages.php";
include "debut_pages_affichable.php";
?>

<div id=contenu class=myDiv>
	<h1 class=center>Classes de Donjons et Dragons</h1>
	<?php
	$result = glob('DnD classes/*');
	echo "<div id=conteneur>";
	foreach ($result as $image) {
		$nom = pathinfo($image, PATHINFO_FILENAME);
		if ($nom != 'Thumbs')
			echo "<div class=jeu>
		      <img src=\"$image\"height=120>
		      <div>$nom</div>
			 </div>
	   ";
	}
	?>
</div>
<?php include "fin_pages.php"; ?>