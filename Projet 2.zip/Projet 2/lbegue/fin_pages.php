  </div>
  </div>
  <div id=pied class="center myDiv">pied de page</div>
  <script>
    document.getElementById('race').addEventListener('change', function() {
      var selectedRace = this.value;
      var sraceDropdown = document.getElementById('srace');

      // Réinitialiser la liste des sraces
      sraceDropdown.innerHTML = '';

      // Effectuer une requête AJAX pour récupérer les sraces
      var xhr = new XMLHttpRequest();
      xhr.open('GET', 'get_sraces.php?race=' + selectedRace, true);
      xhr.onload = function() {
        if (xhr.status === 200) {
          var sraces = JSON.parse(xhr.responseText);

          // Ajouter les options de sraces à la liste déroulante
          sraces.forEach(function(srace) {
            var option = document.createElement('option');
            option.text = srace;
            sraceDropdown.add(option);
          });
        }
      };
      xhr.send();
    });
  </script>
  </body>

  </html>
  <style>
    #pied {
      background: linear-gradient(0.3turn, #992E2E, white, #7F513E);
    }

    .card {
      background-color: #ffffff;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      padding: 20px;
      max-width: 400px;
      width: 100%;
      box-sizing: border-box;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
      transform: translateY(-10px);
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .card h2 {
      margin-top: 0;
      color: #333333;
    }

    .card p {
      color: #666666;
    }

    #menuV {
      background-color: #EE82EE;
    }

    #menuV a:hover {
      color: black;
      background: white;
    }

    #menuV a {
      transition: color 0.3s, background-color 0.3s;
      border: solid 1px black;
      display: block;
      background-color: black;
      color: white;
      text-decoration: none;
      margin: 2px;
      padding: 4px;
      text-align: center;
      border-radius: 10px
    }

    #menuH {
      background-color: #B59E54;
    }

    #menuH a:hover {
      color: black;
      background: white;
      background: linear-gradient(0.3turn, #992E2E, white, #7F513E);
    }

    #menuH a {
      transition: color 0.3s, background-color 0.3s;
      border: solid 1px black;
      background-color: black;
      color: white;
      text-decoration: none;
      margin: 2px;
      padding: 4px;
      text-align: center;
      border-radius: 10px
    }

    .OKmsg {
      color: green;
    }

    #logo_G {
      transition: transform 0.5s;
      cursor: pointer;
    }

    #logo_G:hover {
      transform: scale(1.4);
    }

    #logo_D {
      transition: transform 0.5s;
    }

    #logo_D:hover {
      transform: scale(1.5);
    }


    @font-face {
      font-family: logo;
      src: url("Ressources/ethnocentric rg.otf");
      cursor: pointer;
    }

    #banner_title {
      cursor: default;
    }

    .center {
      text-align: center
    }

    .myDiv {
      background-color: #CCC;
      padding: 5px;
      margin: 5px;
      border: solid 1px #666;
      border-radius: 4px;
    }

    #contenu {
      width: 100%;
      min-height: auto;
      background: linear-gradient(0.3turn, #992E2E, white, #7F513E);
      border: solid 2px black;
    }

    #body {
      display: flex;
      background-color: black;
      width: 100%;
    }

    #principal {
      display: flex;
    }

    #banniere {
      padding: 25px;
      text-shadow: 5px 5px 10px black;
      font-family: logo;
      font-size: 500%;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-image: url(https://st.depositphotos.com/25138294/57687/i/450/depositphotos_576873844-stock-photo-old-medieval-inn-beer-barrels.jpg);
      background-position: center;
    }

    td:first-child {
      text-align: right
    }

    #conteneur {
      display: flex;
      flex-wrap: wrap;
    }

    .jeu img {
      width: 100%;
    }

    .jeu:hover {
      transform: scale(1.3);
    }

    .jeu {
      align-items: center;
      border: solid;
      border-radius: 11px;
      justify-content: center;
      padding: 15px;
      margin: 20px;
      box-shadow: 10px 5px 5px black;
      background-color: white;
      font-size: 30px;
      transition: transform 0.4s;
      height: auto;
    }

    details {
      font: 16px "Open Sans", "Arial", sans-serif;
      width: 620px;
    }

    details>summary {
      padding: 2px 6px;
      width: 15em;
      background-color: #ddd;
      border: none;
      box-shadow: 3px 3px 4px black;
      list-style: none;
    }

    details>summary::-webkit-details-marker {
      display: none;
    }

    details>p {
      border-radius: 0 0 10px 10px;
      background-color: #ddd;
      padding: 2px 6px;
      margin: 0;
      box-shadow: 3px 3px 4px black;
    }

    .dokkan_onglet {
      height: auto;
      margin: 5px;
      padding: 5px;
    }

    #dokkan_contenu {
      width: 100%;
      flex-wrap: wrap;
      background-color: gray;
      justify-content: space-between;
    }

    .div1 {
      margin: 5px;
      padding: 5px;
    }

    .div2 {
      margin: 5px;
      padding: 5px;
    }
  </style>