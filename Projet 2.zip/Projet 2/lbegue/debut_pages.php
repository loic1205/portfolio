<?php
// Grain de sel pour les hashages
$GdS = "quicvhzepoirhpdqoiucqhp    gfagcfaoiucgbaeoi*ù^golkcqblgf";

// Vérifier le trucage du cookie
if (isAuthentified()) {
	if (!isset($_COOKIE['usr_id_hash']))
		die("Problème avec les cookie");
	if ($_COOKIE['usr_id_hash'] != hash('sha256', $_COOKIE['usr_id'] . $GdS . 'CO'))
		die("Trucage du cookie détectée !");
}

// Connexion à la base de données
$CO = new PDO('mysql:dbname=lbegue_db;host=127.0.0.1', 'root', '');

// Est-ce que l'internaute est bien authentifié ?
function isAuthentified()
{
	return isset($_COOKIE['usr_id']);
}

// Repère les erreurs dans les requêtes SQL
function myQuery($CO, $sql, $parameters = null)
{
	if (is_null($parameters)) { // requête directe
		$result = $CO->query($sql);
		$error = $CO->errorInfo();
		if ($error[1])
			die("<div style=background:red>$error[2]</div>");
		return $result;
	} else { // requête préparer
		$req = $CO->prepare($sql);
		$req->execute($parameters);
		$error = $req->errorInfo();
		if ($error[1])
			die("<div style=background:red>$error[2]</div>");
		return $req;
	}
}

$debut_pages = true;
