<?php
include "debut_pages.php";

if (isAuthentified()) header('location:index.php');

// Traitement
$errors = array('login' => "", 'pwd1' => "", 'pwd2' => "");
if (isset($_POST['login'])) {
   $login = $_POST['login'];
   $mdp1 = $_POST['mdp1'];
   $mdp2 = $_POST['mdp2'];

   //Gestion des erreurs
   if (strlen($login) < 3 || strlen($login) > 15) {
      $errors['login'] = '<i style=color:red; class="fa-solid fa-circle-exclamation"></i> Le login doit faire entre 3 et 15 caractères ';
   }
   if (!preg_match('~^[a-z0-9_\'-]+$~i', $login)) {
      $errors['login'] .= '<i style=color:red; class="fa-solid fa-circle-exclamation"></i> Le login contient des caractères interdits. ';
   }
   $checkLogin = $CO->prepare("SELECT usr_id FROM user WHERE usr_login = :login ");
   $checkLogin->execute(array(':login' => $login));
   if ($checkLogin->rowCount()) {
      $errors['login'] .= '<i style=color:red; class="fa-solid fa-circle-exclamation"></i> Ce login est déja utilisé ';
   }
   if (strlen($mdp1) < 8) {
      $errors['pwd1'] = '<i style=color:red; class="fa-solid fa-circle-exclamation"></i> Le mot de passe doit faire minimum 8 caractères ';
   }
   if ($mdp1 != $mdp2) {
      $errors['pwd2'] = '<i style=color:red; class="fa-solid fa-circle-exclamation"></i> Le mot de passe est mal confirmé ';
   }

   if (empty($errors['login']) && empty($errors['pwd1'])) {
      $ip = $_SERVER['REMOTE_ADDR'];
      $mdp = hash('sha256', $mdp1 . $GdS . 'PWD');
      $insert = $CO->prepare("INSERT INTO user (usr_login, usr_pwd, usr_ip_inscription) VALUES (:login, :mdp, :ip)");
      $insert->execute(array(':login' => $login, ':mdp' => $mdp, ':ip' => $ip));

      // Redirection vers l'authentification
      header('location:connexion.php?justSubscribe=1');
   }
}

include "debut_pages_affichable.php";
?>

<!-- Affichage -->
<div id=contenu class=myDiv>
   <form method=post>
      <h1 class=titre_inscription>Inscrivez-vous sur notre site</h1>
      <table>
         <tr>
            <td width=210px><label for=login>Votre login *:</label></td>
            <td width=180px><input id=login name=login required placeholder=login value="<?= isset($_POST['login']) ? htmlspecialchars($_POST['login'], ENT_QUOTES) : ""; ?>"></td>
            <td width=auto><span class=error><?= $errors['login']; ?></span></td>
         </tr>
         <tr>
            <td><label for=mdp1>Votre mot de passe *:</label></td>
            <td><input id=mdp1 name=mdp1 type=password required placeholder='mot de passe'></td>
            <td><span class=error><?= $errors['pwd1']; ?></span></td>
         </tr>
         <tr>
            <td><label for=mdp2>Confirmez votre mot de passe *:</label></td>
            <td><input id=mdp2 name=mdp2 type=password required placeholder='confirmer le mot de passe'></td>
            <td><span class=error><?= $errors['pwd2']; ?></span></td>
         </tr>
         <tr>
            <td></td>
            <td style=display:flex><input id=acknowledge name=acknowledge type=checkbox required>
               <label for=acknowledge>En cochant cette case, vous reconnaissez avoir lu et accepté notre politique de confidentialité.</label>
         </tr>
         <tr>
            <td></td>
            <td><small>(* : champs obligatoires)</small></td>
         </tr>
         <tr>
            <td></td>
            <td><input type=submit value="S'inscrire"></td>
         </tr>
      </table>
   </form>
</div>

<?php include "fin_pages.php"; ?>